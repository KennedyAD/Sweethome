function test(){
    var a = "a" +
    "b".toUpperCase();
}
