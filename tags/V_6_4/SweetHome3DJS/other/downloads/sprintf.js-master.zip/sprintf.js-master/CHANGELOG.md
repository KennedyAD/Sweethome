## 1.1.2 (NOT YET RELEASED)

* Update Travis config to test on all supported Node versions (i.e. 4+)
* Reorganize README; add instructions re polyfills
* Refactor the code

## 1.1.1 (2017-05-29)

* This CHANGELOG
* Various optimizations for modern browsers
* Fix %g, %o, %x and %X specifiers
* Use ESLint instead of JSHint
* Add CONTRIBUTORS file
