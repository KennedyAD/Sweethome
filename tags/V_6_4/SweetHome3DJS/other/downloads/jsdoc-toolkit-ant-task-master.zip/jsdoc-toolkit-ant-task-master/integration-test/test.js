/**
 * Test that the jsdoctoolkit ant task runs (not that the jsdoctoolkit itself works)
 *
 * @constructor
 */
function Test(foo){
    this.aTestProperty = foo;
}

Test.prototype.aTestMethod = function(){
}