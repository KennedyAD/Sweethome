/**
 * @constructor
 */
function Something(foo){
    this.somethingProperty = foo;
}

Something.prototype.somethingMethod = function(){
}