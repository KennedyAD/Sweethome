(function() {
    var w = window;

    w.hello = function(a, abc) {
        "a:nomunge";
        w.alert("Hello, " + a);
    };
})();
