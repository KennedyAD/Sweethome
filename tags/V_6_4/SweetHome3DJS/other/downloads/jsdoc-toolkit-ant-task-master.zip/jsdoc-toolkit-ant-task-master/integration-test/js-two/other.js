/**
 * @constructor
 */
function Other(foo){
    this.otherProperty = foo;
}

Other.prototype.otherMethod = function(){
}